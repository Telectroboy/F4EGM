#!/usr/bin/env bash
# OpenGD77 MD-UV380 RX/TX Dual Watch: one-command, reproducible source build.
# Does not communicate with / flash the radio. Does not alter the codeplug.
set -Eeuo pipefail

BASE_URL="https://github.com/mangelajo/opengd77-rt3s-experiments.git"
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
WORK="$ROOT/opengd77_rxtx_build"
ENGINE="auto"
LOCAL_SOURCE=""
INSTALL_DEPS=0
CHECK_ONLY=0
JOBS="${JOBS:-4}"

usage() {
  cat <<'EOT'
OpenGD77 MD-UV380 RX/TX Dual Watch — compilation automatisee (R20260131).

Utilisation:
  bash build_opengd77_rxtx.sh --install-deps    # Debian 13 / Ubuntu / Arch
  bash build_opengd77_rxtx.sh [--engine=auto|podman|docker|native] [--workdir=DIR]
  bash build_opengd77_rxtx.sh --source=/chemin/vers/repo [--engine=native]
  bash build_opengd77_rxtx.sh --check-only [--source=/chemin/vers/repo]

- Par defaut: clone le fork public R20260131; Podman, Docker ou GCC ARM natif.
- --install-deps: Debian 13/Ubuntu (apt) ou Arch/CachyOS (pacman).
  Installer git, make, Python 3, gcc natif pour les tests, Podman et auxiliaires.
  Ne PAS executer tout le script en root: sudo est utilise seulement pour apt/pacman.
- Compile AVANT puis APRES patch, conserve les logs, calcule les tailles et SHA256.
- N'ECRIT JAMAIS sur le poste radio. Binaires experimentaux, NON TESTES SUR RADIO.
EOT
}
fail() { printf '[ERREUR] %s\n' "$*" >&2; exit 1; }
info() { printf '\n[INFO] %s\n' "$*"; }
has() { command -v "$1" >/dev/null 2>&1; }

for arg in "$@"; do
  case "$arg" in
    --install-deps) INSTALL_DEPS=1 ;;
    --check-only) CHECK_ONLY=1 ;;
    --engine=*) ENGINE="${arg#*=}" ;;
    --source=*) LOCAL_SOURCE="${arg#*=}" ;;
    --workdir=*) WORK="${arg#*=}" ;;
    -h|--help) usage; exit 0 ;;
    *) usage >&2; fail "Argument inconnu: $arg" ;;
  esac
done
case "$ENGINE" in auto|podman|docker|native) ;; *) fail "Moteur incorrect: $ENGINE";; esac
[ -f "$ROOT/patch_opengd77_dual_watch.py" ] || fail "Patch manquant dans le dossier du script. Decompresser tout le ZIP."
[ -f "$ROOT/rx_tx_watch_core.cfrag" ] || fail "Noyau du patch manquant."
[ -x "$ROOT/run_tests.sh" ] || chmod u+x "$ROOT/run_tests.sh"

# Do not run the full build as root. Only package management elevates privileges.
run_package_manager() {
  if [ "$(id -u)" -eq 0 ]; then
    "$@"
  elif has sudo; then
    sudo "$@"
  else
    fail "sudo absent et utilisateur non-root. Installer les dependances en root, puis relancer ce script avec votre utilisateur."
  fi
}

if [ "$INSTALL_DEPS" -eq 1 ]; then
  if has apt-get; then
    info "Debian/Ubuntu: installation des dependances via apt (sudo seulement pour apt)."
    run_package_manager apt-get update
    run_package_manager apt-get install -y --no-install-recommends \
      ca-certificates git make python3 gcc podman uidmap passt slirp4netns fuse-overlayfs
  elif has pacman; then
    info "Arch/CachyOS: installation des dependances via pacman."
    run_package_manager pacman -S --needed --noconfirm git make python gcc podman
  else
    fail "Distribution non prise en charge par --install-deps. Installer git, make, python3, gcc et podman manuellement."
  fi
fi

for command in python3 make cc; do
  has "$command" || fail "Commande '$command' absente. Installer les dependances (sur Debian 13 : --install-deps)."
done
if [ -z "$LOCAL_SOURCE" ]; then
  has git || fail "git absent. Utiliser --install-deps ou installer git."
fi

if [ "$CHECK_ONLY" -eq 1 ]; then
  ENGINE=check-only
elif [ "$ENGINE" = auto ]; then
  if has podman && podman info >/dev/null 2>&1; then
    ENGINE=podman
  elif has docker && docker info >/dev/null 2>&1; then
    ENGINE=docker
  elif has arm-none-eabi-gcc && has arm-none-eabi-objcopy && has arm-none-eabi-size; then
    ENGINE=native
  else
    fail "Aucun moteur utilisable (Podman, Docker, GCC ARM). Sur Debian 13 : relancer avec --install-deps."
  fi
fi
if [ "$ENGINE" = podman ] || [ "$ENGINE" = docker ]; then
  has "$ENGINE" || fail "$ENGINE absent."
  "$ENGINE" info >/dev/null 2>&1 || fail "$ENGINE installe mais inaccessible. Pour Podman rootless Debian: verifier /etc/subuid, /etc/subgid, uidmap et le support des espaces de noms utilisateur."
elif [ "$ENGINE" = native ]; then
  for command in arm-none-eabi-gcc arm-none-eabi-objcopy arm-none-eabi-size; do has "$command" || fail "$command absent. Utiliser un moteur Podman/Docker ou installer GCC ARM et newlib."; done
fi
info "Moteur choisi: $ENGINE"

mkdir -p -- "$WORK"
WORK="$(cd -- "$WORK" && pwd)"
LOG="$WORK/logs"
OUT="$WORK/resultats"
SRC="$WORK/sources_originales"
MOD="$WORK/sources_modifiees"
mkdir -p -- "$LOG" "$OUT"

if [ ! -f "$SRC/MDUV380_firmware/Makefile" ]; then
  if [ -e "$SRC" ]; then fail "Dossier source incomplet deja present: $SRC (ne sera pas supprime automatiquement)."; fi
  info "Recuperation de la base source (copie distincte, aucune modification sur le poste)."
  if [ -n "$LOCAL_SOURCE" ]; then
    [ -d "$LOCAL_SOURCE" ] || fail "Source inexistante: $LOCAL_SOURCE"
    cp -a -- "$LOCAL_SOURCE" "$SRC"
    if [ ! -f "$SRC/MDUV380_firmware/Makefile" ]; then
      fail "Le chemin source doit pointer vers la racine du depot (contenant MDUV380_firmware/Makefile)."
    fi
  else
    git clone --depth 1 --branch main -- "$BASE_URL" "$SRC" 2>&1 | tee "$LOG/git_clone.log"
  fi
fi
[ -f "$SRC/MDUV380_firmware/application/source/user_interface/uiChannelMode.c" ] || fail "Source uiChannelMode.c manquante."
[ -f "$SRC/MDUV380_firmware/application/include/user_interface/menuSystem.h" ] || fail "Source menuSystem.h manquante."
[ -f "$SRC/MDUV380_firmware/Containerfile" ] || [ "$ENGINE" = native ] || [ "$ENGINE" = check-only ] || fail "Containerfile absent du depot. Utiliser --engine=native ou adapter la base."

REV="non_gite"
if [ -d "$SRC/.git" ]; then REV="$(git -C "$SRC" rev-parse HEAD)"; fi
printf 'Source: %s\nRevision: %s\nMoteur: %s\nDate UTC: %s\n' "$BASE_URL" "$REV" "$ENGINE" "$(date -u +'%Y-%m-%dT%H:%M:%SZ')" > "$OUT/source.txt"

info "Verification du correctif (les fichiers originaux restent intacts)."
"$ROOT/run_tests.sh" 2>&1 | tee "$LOG/tests.log"
python3 "$ROOT/patch_opengd77_dual_watch.py" "$SRC" --check > "$LOG/verification_ancres.diff" || {
  cat "$LOG/verification_ancres.diff" >&2
  fail "Le patch ne s'applique pas sur cette version des sources. Aucun code source modifie."
}
# If the modified source tree from V3 already exists, ensure it is an exact,
# safely upgradeable V3 before allowing compilation. No file changed in --check-only.
CHANNEL_MOD="$MOD/MDUV380_firmware/application/source/user_interface/uiChannelMode.c"
if [ -f "$CHANNEL_MOD" ]; then
  python3 "$ROOT/upgrade_existing_v3_source.py" "$CHANNEL_MOD" --check || fail "Source modifiee non reconnue; aucune modification."
fi
if [ "$CHECK_ONLY" -eq 1 ]; then
  info "Tests, ancres et migration V3/V4/V5 verifies. Compilation non demandee (--check-only)."
  exit 0
fi

if [ ! -d "$MOD" ]; then
  info "Creation d'une copie des sources pour le patch."
  cp -a -- "$SRC" "$MOD"
  python3 "$ROOT/patch_opengd77_dual_watch.py" "$MOD" --apply 2>&1 | tee "$LOG/application_patch.log"
else
  if ! grep -q 'Lightweight RX/TX watch for analogue MD-UV380 channel mode' "$MOD/MDUV380_firmware/application/source/user_interface/uiChannelMode.c"; then
    fail "Dossier source modifie deja present, mais correctif absent. Aucune modification automatique."
  fi
  info "Copie modifiee deja presente : migration V3/V4 vers V5 si necessaire."
  prior=$(python3 "$ROOT/upgrade_existing_v3_source.py" "$CHANNEL_MOD" --check) || fail "Core V3/V4/V5 inconnu, aucun changement."
  case "$prior" in
    'V3 CHECK OK'*|'V4 CHECK OK'*)
      from_version=${prior%% *}
      for ext in bin elf; do
        previous="$OUT/OpenGD77_MDUV380_R20260131_RXTX_DUALWATCH_EXPERIMENTAL.$ext"
        saved="$OUT/OpenGD77_MDUV380_R20260131_RXTX_DUALWATCH_${from_version}_BACKUP.$ext"
        if [ -s "$previous" ] && [ ! -e "$saved" ]; then
          cp -- "$previous" "$saved"
          info "$from_version $ext sauvegarde : $saved"
        fi
      done
      if [ -f "$OUT/AUDIT_DUALWATCH.txt" ] && [ ! -f "$OUT/AUDIT_DUALWATCH_${from_version}_BACKUP.txt" ]; then
        cp -- "$OUT/AUDIT_DUALWATCH.txt" "$OUT/AUDIT_DUALWATCH_${from_version}_BACKUP.txt"
      fi
      ;;
  esac
  python3 "$ROOT/upgrade_existing_v3_source.py" "$CHANNEL_MOD" --apply || fail "Echec migration V3/V4 -> V5."
fi

build_one() {
  local title="$1" parent="$2" file="$3"
  local fw="$parent/MDUV380_firmware"
  local buildlog="$LOG/${title}_compilation.log"
  info "Compilation $title - toutes les sorties seront enregistrees dans $buildlog"
  printf 'Commande / moteur: %s\n' "$ENGINE" > "$buildlog"
  if [ "$ENGINE" = native ]; then
    (make -C "$fw" -j"$JOBS" all PLATFORM=MDUV380) >>"$buildlog" 2>&1 || {
      tail -n 90 "$buildlog" >&2
      fail "Echec compilation $title. Consulter $buildlog"
    }
  else
    (make -C "$fw" build "CONTAINER_ENGINE=$ENGINE" "JOBS=$JOBS" PLATFORM=MDUV380) >>"$buildlog" 2>&1 || {
      tail -n 90 "$buildlog" >&2
      fail "Echec compilation $title. Consulter $buildlog"
    }
  fi
  local bin="$fw/build/OpenGD77_MDUV380.bin"
  local elf="$fw/build/MDUV380_FW.elf"
  [ -s "$bin" ] && [ -s "$elf" ] || fail "Compilation $title sans binaire/ELF au chemin attendu (consulter $buildlog)."
  cp -- "$bin" "$OUT/$file.bin"
  cp -- "$elf" "$OUT/$file.elf"
  info "$title: $(wc -c < "$bin") octets, fichier $OUT/$file.bin"
}

# Both builds use the identical compiler and identical upstream source revision.
build_one "baseline" "$SRC" "OpenGD77_MDUV380_R20260131_base"
build_one "dualwatch" "$MOD" "OpenGD77_MDUV380_R20260131_RXTX_DUALWATCH_EXPERIMENTAL"

info "Rapport de taille et sommes SHA256."
python3 - "$OUT" <<'PY'
import pathlib,sys,hashlib
p=pathlib.Path(sys.argv[1]); a=p/'OpenGD77_MDUV380_R20260131_base.bin'; b=p/'OpenGD77_MDUV380_R20260131_RXTX_DUALWATCH_EXPERIMENTAL.bin'
sza=a.stat().st_size; szb=b.stat().st_size; diff=szb-sza
head=f"Base      : {sza:,} octets\nDual Watch: {szb:,} octets\nDelta BIN : {diff:+,} octets\n"
info="ATTENTION : la taille brute BIN ne mesure pas toujours la variation de la zone .text; voir les ELF / fichiers de map dans sources.\n"
content=head+info
for file in (a,b): content+=f"SHA256 {file.name}: {hashlib.sha256(file.read_bytes()).hexdigest()}\n"
(p/'TAILLES_ET_SHA256.txt').write_text(content,encoding='utf-8')
print(content)
PY
if has arm-none-eabi-size; then
  {
    arm-none-eabi-size -A "$OUT/OpenGD77_MDUV380_R20260131_base.elf"
    printf '\n---- PATCH ----\n'
    arm-none-eabi-size -A "$OUT/OpenGD77_MDUV380_R20260131_RXTX_DUALWATCH_EXPERIMENTAL.elf"
  } > "$OUT/TAILLE_SECTIONS_ARM.txt" 2>&1 || true
elif [ "$ENGINE" = podman ] || [ "$ENGINE" = docker ]; then
  # Use the exact container image already used by the two firmware builds.
  "$ENGINE" run --rm -v "$OUT:/resultats:Z" opengd77-mduv380-builder:latest \
    sh -c 'arm-none-eabi-size -A /resultats/OpenGD77_MDUV380_R20260131_base.elf; echo "---- PATCH ----"; arm-none-eabi-size -A /resultats/OpenGD77_MDUV380_R20260131_RXTX_DUALWATCH_EXPERIMENTAL.elf' \
    > "$OUT/TAILLE_SECTIONS_ARM.txt" 2>&1 || true
fi
cat > "$OUT/AVANT_FLASH.txt" <<'TXT'
FIRMWARE DE TEST, NON VALIDE SUR RADIO. VERSION BASE R20260131.
CE N'EST PAS UNE MODIFICATION DU BIN OFFICIEL R20260504.
Sauvegarder le codeplug et les donnees radio avant tout flash.
Le code AMBE proprietaire est absent de l'image compilee : le chargeur
OpenGD77 doit le prendre d'un firmware donneur compatible, conforme
au processus officiel OpenGD77.
Verifier la variante du poste : MD-UV380 / RT3S standard, PAS la 10 W+.
Contrôler d'abord les receptions FM/CTCSS, PTT, balayage et veille ECO.
TXT
info "Audit ELF/BIN automatique V5."
python3 "$ROOT/audit_opengd77_dualwatch.py" "$WORK" > "$LOG/audit_dualwatch.log" 2>&1 || {
  tail -n 80 "$LOG/audit_dualwatch.log" >&2
  fail "Audit V5 echoue. Voir $LOG/audit_dualwatch.log"
}
grep -E '^Delta \.(text|rodata|data|bss)|Marge avant codec' "$OUT/AUDIT_DUALWATCH.txt" || true
info "TERMINE : resultats V5 disponibles dans $OUT"
info "Rapport : $OUT/AUDIT_DUALWATCH.txt"
info "NE PAS FLASHER avant validation / sauvegarde."
