#!/usr/bin/env python3
"""Transactional minimal MD-UV380 FM RX/TX Dual Watch patch for OpenGD77 R20260131.

Only 2 source files edited. An automatic, compact state machine is inserted in
uiChannelMode.c; there is no persistent setting, new task or scan object.
Check anchored content first and apply only if every source anchor matches.
"""
import argparse
import difflib
from pathlib import Path
import sys

MARK = " * Lightweight RX/TX watch for analogue MD-UV380 channel mode."


def replace_one(data, before, after, label):
    count = data.count(before)
    if count != 1:
        raise RuntimeError(f"{label}: expected one anchor, got {count}. No files changed.")
    return data.replace(before, after, 1)


def guarded(code):
    return "#if defined(PLATFORM_MDUV380)\n" + code + "#endif\n"


def patch_header(data):
    before = "\tCH_SCREEN_QUICK_MENU_AUDIO_MUTE,\n\tNUM_CH_SCREEN_QUICK_MENU_ITEMS"
    after = "\tCH_SCREEN_QUICK_MENU_AUDIO_MUTE,\n" + guarded("\tCH_SCREEN_QUICK_MENU_RXTX_WATCH,\n") + "\tNUM_CH_SCREEN_QUICK_MENU_ITEMS"
    return replace_one(data, before, after, "quick menu enum")


def patch_channel(data, core):
    if MARK in data:
        raise RuntimeError("uiChannelMode.c already includes RX/TX watch")
    data = replace_one(data,
        "static menuStatus_t menuQuickChannelExitStatus = MENU_STATUS_SUCCESS;\n",
        "static menuStatus_t menuQuickChannelExitStatus = MENU_STATUS_SUCCESS;\n\n" + core + "\n",
        "core insertion")
    # Returning from the quick menu (or another screen) invokes
    # uiChannelModeFirstRun(), which reloads the codeplug channel and clears
    # rxTxState. Resume only when the current channel index AND both stored
    # frequencies are unchanged. This is volatile, not a saved setting.
    data = replace_one(data,
        "static menuStatus_t uiChannelModeFirstRun(void)\n{\n",
        "static menuStatus_t uiChannelModeFirstRun(void)\n{\n" +
        guarded("\tconst uint32_t rxTxResumeRx = (rxTxState != RXTX_OFF) ? currentChannelData->rxFreq : 0U;\n"
                "\tconst uint32_t rxTxResumeTx = (rxTxState != RXTX_OFF) ? currentChannelData->txFreq : 0U;\n"
                "\tconst int rxTxResumeChannel = uiDataGlobal.currentSelectedChannelNumber;\n"),
        "first-run preservation")
    data = replace_one(data,
        "\t\tif ((uiDataGlobal.displayQSOState == QSO_DISPLAY_CALLER_DATA) && (trxGetMode() == RADIO_MODE_ANALOG))\n",
        guarded("\t\tif (rxTxResumeRx && (rxTxResumeRx == currentChannelData->rxFreq) &&\n"
                "\t\t\t(rxTxResumeTx == currentChannelData->txFreq) &&\n"
                "\t\t\t(rxTxResumeChannel == uiDataGlobal.currentSelectedChannelNumber))\n"
                "\t\t{\n\t\t\trxTxStart();\n\t\t}\n") +
        "\t\tif ((uiDataGlobal.displayQSOState == QSO_DISPLAY_CALLER_DATA) && (trxGetMode() == RADIO_MODE_ANALOG))\n",
        "first-run resume (same channel only)")
    data = replace_one(data,
        "\t\tif (ev->events == NO_EVENT)\n",
        guarded("\t\trxTxTick(ev);\n") + "\t\tif (ev->events == NO_EVENT)\n",
        "channel mode tick")
    # Channel reload finishes configuring the new frequency itself: invalidate
    # watch early without retuning the old or possibly uninitialised channel.
    data = replace_one(data,
        "void uiChannelModeLoadChannelData(bool useChannelDataInMemory, bool loadVoicePromptAnnouncement)\n{\n",
        "void uiChannelModeLoadChannelData(bool useChannelDataInMemory, bool loadVoicePromptAnnouncement)\n{\n" + guarded("\trxTxState = RXTX_OFF;\n"),
        "channel reload interlock")
    data = replace_one(data,
        "\t\t\tuiDataGlobal.talkaround = false; // Talkaround and reverseRepeater are mutually exclusive.\n",
        guarded("\t\t\trxTxStop();\n") + "\t\t\tuiDataGlobal.talkaround = false; // Talkaround and reverseRepeater are mutually exclusive.\n",
        "reverse repeater interlock")
    # OpenGD77's quick-menu initialization calls uiChannelModeStopScanning(),
    # which can reload the channel when voice prompts are enabled. Preserve
    # the active watch across that reload, while parking on the normal RX.
    data = replace_one(data,
        "\t\tuiChannelModeStopScanning();\n\t\tuiDataGlobal.QuickMenu.tmpDmrDestinationFilterLevel = nonVolatileSettings.dmrDestinationFilter;\n",
        guarded("\t\tbool rxTxWasEnabled = (rxTxState != RXTX_OFF);\n\t\tif (rxTxWasEnabled)\n\t\t{\n\t\t\trxTxTune(false, ticksGetMillis());\n\t\t}\n") +
        "\t\tuiChannelModeStopScanning();\n" +
        guarded("\t\tif (rxTxWasEnabled)\n\t\t{\n\t\t\trxTxStart();\n\t\t}\n") +
        "\t\tuiDataGlobal.QuickMenu.tmpDmrDestinationFilterLevel = nonVolatileSettings.dmrDestinationFilter;\n",
        "quick menu reload/watch continuity")
    data = replace_one(data,
        "\t\tuiDataGlobal.QuickMenu.tmpAudioMute = audioAmpIsMuted();\n",
        guarded("\t\trxTxMenuChoice = (rxTxState != RXTX_OFF);\n") +
        "\t\tuiDataGlobal.QuickMenu.tmpAudioMute = audioAmpIsMuted();\n",
        "quick menu preparation")
    data = replace_one(data,
        "\t\t\t\tcase CH_SCREEN_QUICK_MENU_AUDIO_MUTE:\n\t\t\t\t\tleftSide = currentLanguage->mute;\n\t\t\t\t\trightSideConst = (uiDataGlobal.QuickMenu.tmpAudioMute ? currentLanguage->yes : currentLanguage->no);\n\t\t\t\t\tbreak;\n",
        "\t\t\t\tcase CH_SCREEN_QUICK_MENU_AUDIO_MUTE:\n\t\t\t\t\tleftSide = currentLanguage->mute;\n\t\t\t\t\trightSideConst = (uiDataGlobal.QuickMenu.tmpAudioMute ? currentLanguage->yes : currentLanguage->no);\n\t\t\t\t\tbreak;\n" +
        guarded("\t\t\t\tcase CH_SCREEN_QUICK_MENU_RXTX_WATCH:\n\t\t\t\t\tleftSide = \"RX/TX watch\";\n\t\t\t\t\trightSideConst = (rxTxAvailable() ? (rxTxMenuChoice ? currentLanguage->on : currentLanguage->off) : currentLanguage->n_a);\n\t\t\t\t\tbreak;\n"),
        "quick menu view")
    data = replace_one(data,
        "\t\t\t\t\tvoicePromptsAppendLanguageString(leftSide);\n",
        guarded("\t\t\t\t\tif (mNum == CH_SCREEN_QUICK_MENU_RXTX_WATCH)\n\t\t\t\t\t{\n\t\t\t\t\t\tvoicePromptsAppendString(leftSide);\n\t\t\t\t\t}\n\t\t\t\t\telse\n") +
        "\t\t\t\t\tvoicePromptsAppendLanguageString(leftSide);\n",
        "voice prompts: text not in language table")
    data = replace_one(data,
        "\t\t\t\t\tcase CH_SCREEN_QUICK_MENU_AUDIO_MUTE:\n\t\t\t\t\t\tmenuDisplayEntry(i, mNum, buf,",
        "\t\t\t\t\tcase CH_SCREEN_QUICK_MENU_AUDIO_MUTE:\n" + guarded("\t\t\t\t\tcase CH_SCREEN_QUICK_MENU_RXTX_WATCH:\n") + "\t\t\t\t\t\tmenuDisplayEntry(i, mNum, buf,",
        "quick menu presentation attributes")
    # Commit in the main menu branch (no changes to persisted settings).
    data = replace_one(data,
        "\t\t\t\t\t\taudioAmpMute(uiDataGlobal.QuickMenu.tmpAudioMute);\n\t\t\t\t\t}\n\t\t\t\t\tbreak;\n",
        "\t\t\t\t\t\taudioAmpMute(uiDataGlobal.QuickMenu.tmpAudioMute);\n\t\t\t\t\t}\n" +
        guarded("\t\t\t\t\tif (menuDataGlobal.currentItemIndex == CH_SCREEN_QUICK_MENU_RXTX_WATCH)\n\t\t\t\t\t{\n\t\t\t\t\t\tif (rxTxMenuChoice)\n\t\t\t\t\t\t{\n\t\t\t\t\t\t\trxTxStart();\n\t\t\t\t\t\t}\n\t\t\t\t\t\telse\n\t\t\t\t\t\t{\n\t\t\t\t\t\t\trxTxStop();\n\t\t\t\t\t\t}\n\t\t\t\t\t}\n") +
        "\t\t\t\t\tbreak;\n",
        "quick menu commit")
    data = replace_one(data,
        "\t\t\t\tcase CH_SCREEN_QUICK_MENU_AUDIO_MUTE:\n\t\t\t\t\tuiDataGlobal.QuickMenu.tmpAudioMute = true;\n\t\t\t\t\tbreak;\n",
        "\t\t\t\tcase CH_SCREEN_QUICK_MENU_AUDIO_MUTE:\n\t\t\t\t\tuiDataGlobal.QuickMenu.tmpAudioMute = true;\n\t\t\t\t\tbreak;\n" +
        guarded("\t\t\t\tcase CH_SCREEN_QUICK_MENU_RXTX_WATCH:\n\t\t\t\t\tif (rxTxAvailable())\n\t\t\t\t\t{\n\t\t\t\t\t\trxTxMenuChoice = true;\n\t\t\t\t\t}\n\t\t\t\t\tbreak;\n"),
        "quick menu right")
    data = replace_one(data,
        "\t\t\t\tcase CH_SCREEN_QUICK_MENU_AUDIO_MUTE:\n\t\t\t\t\tuiDataGlobal.QuickMenu.tmpAudioMute = false;\n\t\t\t\t\tbreak;\n",
        "\t\t\t\tcase CH_SCREEN_QUICK_MENU_AUDIO_MUTE:\n\t\t\t\t\tuiDataGlobal.QuickMenu.tmpAudioMute = false;\n\t\t\t\t\tbreak;\n" +
        guarded("\t\t\t\tcase CH_SCREEN_QUICK_MENU_RXTX_WATCH:\n\t\t\t\t\trxTxMenuChoice = false;\n\t\t\t\t\tbreak;\n"),
        "quick menu left")
    # RED exits the quick menu without applying pending changes. If the
    # built-in StopScanning() reloads the channel, restore the prior watch.
    data = replace_one(data,
        "\t\telse if (KEYCHECK_SHORTUP(ev->keys, KEY_RED))\n\t\t{\n\t\t\tuiChannelModeStopScanning();\n\t\t\tmenuSystemPopPreviousMenu();\n\t\t\treturn;\n",
        "\t\telse if (KEYCHECK_SHORTUP(ev->keys, KEY_RED))\n\t\t{\n" +
        guarded("\t\t\tbool rxTxWasEnabled = (rxTxState != RXTX_OFF);\n") +
        "\t\t\tuiChannelModeStopScanning();\n" +
        guarded("\t\t\tif (rxTxWasEnabled)\n\t\t\t{\n\t\t\t\trxTxStart();\n\t\t\t}\n") +
        "\t\t\tmenuSystemPopPreviousMenu();\n\t\t\treturn;\n",
        "quick menu cancel continuity")
    # Hook at the scan function declaration, not at fragile surrounding
    # comments/whitespace. The forward prototype ends in a semicolon, and
    # therefore cannot match this anchor. Stop watch before beginning any
    # normal channel scan (the watch itself never uses scanStart()).
    data = replace_one(data,
        "static void scanStart(bool longPressBeep)\n{\n",
        "static void scanStart(bool longPressBeep)\n{\n" + guarded("\trxTxStop();\n"),
        "normal scan interlock (scanStart body)")
    return data


def read_text(path):
    raw = path.read_bytes()
    crlf = b"\r\n" in raw
    return raw.decode("latin1").replace("\r\n", "\n"), crlf


def encode_text(text, crlf):
    return (text.replace("\n", "\r\n") if crlf else text).encode("latin1")


def patch_source(root, core, check):
    possible = [root / "MDUV380_firmware", root]
    firmware = next((p for p in possible if (p / "application" / "source" / "user_interface" / "uiChannelMode.c").is_file()), None)
    if firmware is None:
        raise RuntimeError("No OpenGD77 source tree: expected MDUV380_firmware/application/source/user_interface/uiChannelMode.c")
    channel = firmware / "application" / "source" / "user_interface" / "uiChannelMode.c"
    menu = firmware / "application" / "include" / "user_interface" / "menuSystem.h"
    originals = {p: read_text(p) for p in (channel, menu)}
    core_text = core.read_text(encoding="utf-8").rstrip("\n")
    results = {
        channel: patch_channel(originals[channel][0], core_text),
        menu: patch_header(originals[menu][0]),
    }
    # Atomic check: every anchor and backup path confirmed BEFORE writing anything.
    for path in results:
        if not check and path.with_name(path.name + ".dualwatch.bak").exists():
            raise RuntimeError(f"Backup already exists: {path.name}.dualwatch.bak")
    if check:
        for path, result in results.items():
            delta = difflib.unified_diff(originals[path][0].splitlines(), result.splitlines(),
                                         fromfile=str(path), tofile=str(path) + " (patched)", lineterm="")
            print("\n".join(delta))
        print("\n[OK] All anchors matched; nothing was changed")
    else:
        for path, result in results.items():
            path.with_name(path.name + ".dualwatch.bak").write_bytes(path.read_bytes())
            path.write_bytes(encode_text(result, originals[path][1]))
            print(f"[PATCHED] {path} | [BACKUP] {path.name}.dualwatch.bak")
        print("[OK] Source patch applied; firmware not compiled or flashed")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("source_root", type=Path, help="directory containing MDUV380_firmware/")
    group = p.add_mutually_exclusive_group(required=True)
    group.add_argument("--check", action="store_true", help="validate all anchors and print diff; no write")
    group.add_argument("--apply", action="store_true", help="modify sources with .dualwatch.bak backups")
    p.add_argument("--core", type=Path, default=Path(__file__).with_name("rx_tx_watch_core.cfrag"))
    args = p.parse_args()
    try:
        patch_source(args.source_root.resolve(), args.core, args.check)
    except (RuntimeError, OSError) as e:
        print("[ERROR]", e, file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
