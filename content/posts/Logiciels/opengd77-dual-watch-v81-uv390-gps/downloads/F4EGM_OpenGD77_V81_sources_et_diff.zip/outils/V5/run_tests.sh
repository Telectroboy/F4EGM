#!/bin/sh
set -eu
cd "$(dirname "$0")"
echo '=== OpenGD77 RX/TX watch: patched source transformations ==='
python3 tests/test_patch.py
python3 tests/test_upgrade.py
echo '=== OpenGD77 RX/TX watch: FM/CTCSS/priority/hang/PTT host simulation ==='
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror -O2 tests/test_watch_logic.c -o tests/test_watch_logic
./tests/test_watch_logic
echo '=== Minimal ARM Cortex-M4 size probe (independent of real firmware link) ==='
if command -v clang >/dev/null 2>&1; then
  clang --target=arm-none-eabi -mcpu=cortex-m4 -mthumb -Oz -ffunction-sections -fdata-sections -std=c11 -Wall -Wextra -Werror -c tests/size_probe.c -o tests/size_probe_arm.o
  if command -v size >/dev/null 2>&1; then
    size tests/size_probe_arm.o
  fi
else
  echo 'clang absent: size probe skipped'
fi
