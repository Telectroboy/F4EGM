#!/usr/bin/env bash
# Reproducible source build from pinned upstream snapshot, on Debian/Linux.
# Builds Dual Watch V8.1; optionally builds a separate combined APRS Guard image.
# Never flashes radio or uploads anything to the Internet except git fetch.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PIN='b7a0d368a458291c66e6fb1431d7c78627727381'
REMOTE='https://github.com/mangelajo/opengd77-rt3s-experiments.git'
ENGINE="${ENGINE:-native}"
MODE='dualwatch'
WORK="$ROOT/local_build"
for arg in "$@"; do
  case "$arg" in
    --engine=*) ENGINE="${arg#*=}" ;;
    --mode=*) MODE="${arg#*=}" ;;
    --workdir=*) WORK="${arg#*=}" ;;
    -h|--help) echo 'Usage: bash scripts/build_from_zero.sh [--mode=dualwatch|combined] [--engine=podman|docker|native] [--workdir=DIR]'; exit 0 ;;
    *) echo "Unsupported argument: $arg" >&2; exit 2 ;;
  esac
done
case "$MODE" in dualwatch|combined) ;; *) echo 'Bad mode' >&2; exit 2;; esac
case "$ENGINE" in podman|docker|native) ;; *) echo 'Bad compiler engine' >&2; exit 2;; esac
mkdir -p "$WORK"
WORK="$(cd "$WORK" && pwd)"
TOOLS="$WORK/OpenGD77_RX_TX_DualWatch"
SRC="$WORK/upstream_R20260131_pinned"
if [[ ! -e "$SRC/.git" ]]; then
    mkdir -p "$SRC"
    git -C "$SRC" init -q
    git -C "$SRC" remote add origin "$REMOTE"
    git -C "$SRC" fetch --depth=1 origin "$PIN"
    git -C "$SRC" checkout --detach FETCH_HEAD
fi
ACTUAL="$(git -C "$SRC" rev-parse HEAD)"
[[ "$ACTUAL" == "$PIN" ]] || { echo "[ERROR] Source SHA mismatch: $ACTUAL" >&2; exit 2; }
[[ -f "$SRC/MDUV380_firmware/Makefile" ]] || { echo '[ERROR] Missing pinned source tree' >&2; exit 2; }
mkdir -p "$TOOLS"
for v in V5 V7 V8 V81; do cp -a "$ROOT/dualwatch/$v/." "$TOOLS/"; done
V81_OUT="$TOOLS/opengd77_rxtx_build/resultats/OpenGD77_MDUV380_R20260131_F4EGM_DW_V8_1_EXPERIMENTAL.bin"
if [[ -s "$V81_OUT" ]]; then
    echo '[INFO] Existing V8.1 build found, not rebuilding the V5->V7->V8.1 chain.'
else
    bash "$TOOLS/build_opengd77_rxtx.sh" --source="$SRC" --engine="$ENGINE" --workdir="$TOOLS/opengd77_rxtx_build"
    ENGINE="$ENGINE" bash "$TOOLS/build_v7_debian13.sh"
    ENGINE="$ENGINE" bash "$TOOLS/build_v81_debian13.sh"
fi
if [[ "$MODE" == combined ]]; then
  bash "$ROOT/scripts/build_aprs_guard.sh" --mode=combined --workspace="$TOOLS/opengd77_rxtx_build" --engine="$ENGINE"
fi
printf '[OK] Outputs in %s\n' "$TOOLS/opengd77_rxtx_build/resultats"
