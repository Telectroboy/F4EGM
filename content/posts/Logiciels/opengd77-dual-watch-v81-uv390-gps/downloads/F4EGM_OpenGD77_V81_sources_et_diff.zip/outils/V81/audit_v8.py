#!/usr/bin/env python3
"""Read-only V7/V8 ARM ELF/BIN size and reserved-codec checks (stdlib only)."""
from __future__ import annotations
import hashlib
import struct
import sys
from pathlib import Path

V7='OpenGD77_MDUV380_R20260131_RXTX_DUALWATCH_V7_PERCHANNEL_EXPERIMENTAL'
V8='OpenGD77_MDUV380_R20260131_RXTX_DUALWATCH_V8_LARGE_LABEL_EXPERIMENTAL'
FLASH=0x0800C000
CODEC=0x0807537C
MIN_MARGIN=16384
EXPECTED_CODEC_SIZE=297904


def elf_alloc(path: Path) -> dict[str, tuple[int,int]]:
    data=path.read_bytes()
    if data[:6] != b'\x7fELF\x01\x01' or struct.unpack_from('<H',data,18)[0] != 40:
        raise ValueError('Not 32-bit LE ARM ELF: '+str(path))
    off=struct.unpack_from('<I',data,32)[0]
    size=struct.unpack_from('<H',data,46)[0]
    num=struct.unpack_from('<H',data,48)[0]
    names_index=struct.unpack_from('<H',data,50)[0]
    sections=[struct.unpack_from('<10I',data,off+n*size) for n in range(num)]
    names_hdr=sections[names_index]
    names=data[names_hdr[4]:names_hdr[4]+names_hdr[5]]
    alloc={}
    for s in sections:
        if (s[2] & 0x2) and s[5]:
            end=names.find(b'\x00',s[0])
            if end < 0: raise ValueError('Invalid ELF string table')
            name=names[s[0]:end].decode('ascii','replace')
            alloc[name]=(s[3],s[5])
    return alloc


def inspect(out: Path, label: str):
    path=out/(label+'.bin')
    elf=out/(label+'.elf')
    if not path.is_file() or not elf.is_file():
        raise FileNotFoundError(f'Missing BIN or ELF for {label}')
    data=path.read_bytes()
    alloc=elf_alloc(elf)
    if '.text' not in alloc or '.codec_bin_section_1' not in alloc:
        raise ValueError('Expected firmware ELF sections missing')
    codec_addr,codec_size=alloc['.codec_bin_section_1']
    if codec_addr != CODEC or codec_size != EXPECTED_CODEC_SIZE:
        raise ValueError('Codec reserve moved or resized')
    pre_end=max((addr+size for name,(addr,size) in alloc.items()
                 if FLASH <= addr < CODEC and addr+size <= CODEC),default=0)
    if pre_end <= FLASH or pre_end > CODEC:
        raise ValueError('Invalid pre-codec Flash layout')
    if len(data) < CODEC-FLASH:
        raise ValueError('Binary shorter than codec start')
    free=data[pre_end-FLASH:CODEC-FLASH]
    if len(free)!=CODEC-pre_end or any(v!=0xFF for v in free):
        raise ValueError('Flash margin is not all 0xFF')
    if len(free)<MIN_MARGIN:
        raise ValueError('Flash margin under safety threshold')
    if b'DW:R' not in data or b'DW:T' not in data:
        raise ValueError('Both DW receive indicators must be in the BIN')
    return data,alloc,pre_end,len(free)


def report(out: Path) -> None:
    b7,a7,end7,margin7=inspect(out,V7)
    b8,a8,end8,margin8=inspect(out,V8)
    if len(b7)!=len(b8): raise ValueError('Unexpected BIN size change')
    if b7==b8: raise ValueError('V8 BIN is byte-identical to V7; no effective patch')
    rows=['AUDIT RX/TX DUAL WATCH V8 - MD-UV380 - R20260131',
          '','V8 modifies display font and y position only (source diff checked by patch).',
          'This ELF/BIN audit does not prove the physical display is correct.','']
    for name,data,alloc,free in [(V7,b7,a7,margin7),(V8,b8,a8,margin8)]:
        rows += [name, f'  BIN size: {len(data)} bytes',
                 f'  SHA256: {hashlib.sha256(data).hexdigest()}',
                 f'  .text={alloc.get(".text",(0,0))[1]}, .rodata={alloc.get(".rodata",(0,0))[1]}, .bss={alloc.get(".bss",(0,0))[1]}',
                 f'  pre-codec free Flash: {free} bytes (checked FF)',
                 '']
    rows.append('V8 versus V7:')
    for sect in ['.text','.rodata','.data','.bss']:
        a=a7.get(sect,(0,0))[1]; b=a8.get(sect,(0,0))[1]
        rows.append(f'  {sect}: {b-a:+d} bytes')
    rows += [f'  Flash margin delta: {margin8-margin7:+d} bytes',
             f'  BIN differing bytes: {sum(x!=y for x,y in zip(b7,b8))}',
             '', '  Radio timings, codeplug persistence, and menu code were not changed by V8 patch.',
             '  The V7 per-channel flag can be lost if an incompatible CPS rewrites the codeplug.',
             '  Hardware verification of larger label remains necessary.']
    text='\n'.join(rows)+'\n'
    (out/'AUDIT_DUALWATCH_V8.txt').write_text(text)
    print(text)


if __name__=='__main__':
    try:
        if len(sys.argv)!=2: raise ValueError('Usage: python3 audit_v8.py results_directory')
        report(Path(sys.argv[1]))
    except (OSError,ValueError,IndexError,struct.error) as ex:
        print('[ERROR]',ex,file=sys.stderr)
        sys.exit(2)
