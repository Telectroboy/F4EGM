#!/usr/bin/env python3
"""V7 -> V8: change exactly one OpenGD77 DW display call (source-only).

Never modifies the codeplug or radio. No change to the RF state machine,
flash flag, CTCSS, PTT, persistence, or any other display line.
"""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import tempfile

SRC = Path('MDUV380_firmware/application/source/user_interface/uiChannelMode.c')
HEADER = Path('MDUV380_firmware/application/include/functions/codeplug.h')
V7_MARKER = b'V7: channel-local persistent watch; separate status row'
FLAG_MARKER = b'CODEPLUG_CHANNEL_LIBREDMR_FLAG1_RXTX_WATCH'
V7_DRAW = b'displayPrintCentered(DISPLAY_Y_POS_CHANNEL_FIRST_LINE - 12, dwLabel, FONT_SIZE_1);'
V8_DRAW = b'displayPrintCentered(DISPLAY_Y_POS_CHANNEL_FIRST_LINE - 20, dwLabel, FONT_SIZE_3);'
V7_BACKUP_SUFFIX = '.BEFORE_V8.bak'


def validate_source(data: bytes, header: bytes) -> None:
    if V7_MARKER not in data:
        raise ValueError('The source is not the expected V7 (missing revision marker).')
    if FLAG_MARKER not in data or FLAG_MARKER not in header:
        raise ValueError('V7 per-channel persistence not found; refusing modification.')
    for required in (b'"DW:R"', b'"DW:T"', b'#define RXTX_OUTPUT_DWELL_MS 700U',
                     b'#define RXTX_INPUT_DWELL_MS 400U', b'#define RXTX_PRIORITY_PROBE_MS 350U',
                     b'#define RXTX_HANG_MS 1000U'):
        if required not in data:
            raise ValueError('Missing expected V7 code: ' + repr(required))
    if b'\x00' in data:
        raise ValueError('Binary data supplied instead of source file.')


def transform(data: bytes, header: bytes) -> tuple[bytes, bool]:
    validate_source(data, header)
    old_count = data.count(V7_DRAW)
    new_count = data.count(V8_DRAW)
    if old_count == 0 and new_count == 1:
        return data, False
    if old_count != 1 or new_count != 0:
        raise ValueError(f'Unexpected label draw anchors: V7={old_count}, V8={new_count}.')
    # The entire change is one source line. Keep all other bytes identical.
    modified = data.replace(V7_DRAW, V8_DRAW, 1)
    assert modified.count(V8_DRAW) == 1
    return modified, True


def atomic_replace(path: Path, data: bytes) -> None:
    temp = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix=path.name+'.v8-', delete=False) as fp:
            temp = Path(fp.name)
            fp.write(data)
            fp.flush()
            os.fsync(fp.fileno())
        os.chmod(temp, path.stat().st_mode & 0o777)
        os.replace(temp, path)
    finally:
        if temp and temp.exists():
            temp.unlink()


def upgrade(root: Path, apply: bool) -> None:
    source_path, header_path = root / SRC, root / HEADER
    if not source_path.is_file() or not header_path.is_file():
        raise ValueError('Existing V7 sources not found in sources_modifiees.')
    original = source_path.read_bytes()
    patched, change = transform(original, header_path.read_bytes())
    if not change:
        print('[V8] Already applied. Source unchanged.')
        return
    if not apply:
        print('[V8] Check OK. Exactly one draw call would change (6x8 y52 -> 8x16 y44).')
        print('[V8] No radio, codeplug, or source files changed.')
        return
    backup = source_path.with_name(source_path.name + V7_BACKUP_SUFFIX)
    if backup.exists():
        raise ValueError(f'Backup already exists, refusing overwrite: {backup}')
    with backup.open('xb') as f:
        f.write(original)
        f.flush()
        os.fsync(f.fileno())
    try:
        atomic_replace(source_path, patched)
    except BaseException:
        if source_path.read_bytes() != original:
            atomic_replace(source_path, original)
        raise
    print('[V8] Applied single-line display change.')
    print('[V8] V7 source backup:', backup)
    print('[V8] Codeplug, settings, menu, RF timing, and channel flags untouched.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('modified_source_root', type=Path)
    options = parser.add_mutually_exclusive_group(required=True)
    options.add_argument('--check', action='store_true')
    options.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    try:
        upgrade(args.modified_source_root, args.apply)
    except (OSError, ValueError) as ex:
        parser.exit(2, '[ERROR] ' + str(ex) + '\n')
