#!/usr/bin/env python3
"""V8.1 ELF/BIN audit. Checks actual version/credits strings and pre-codec margin."""
import hashlib
from pathlib import Path
import sys
from audit_v8 import inspect

V7 = 'OpenGD77_MDUV380_R20260131_RXTX_DUALWATCH_V7_PERCHANNEL_EXPERIMENTAL'
V8 = 'OpenGD77_MDUV380_R20260131_RXTX_DUALWATCH_V8_LARGE_LABEL_EXPERIMENTAL'
V81 = 'OpenGD77_MDUV380_R20260131_F4EGM_DW_V8_1_EXPERIMENTAL'


def report(out: Path):
    b81, a81, end81, margin81 = inspect(out, V81)
    for text in (b'R20260131-DW8.1', b'F4EGM (RX/TX Watch)', b'DW:R', b'DW:T'):
        if text not in b81:
            raise ValueError('Expected compiled text absent from BIN: '+text.decode())
    if out.joinpath(V8+'.bin').exists() and out.joinpath(V8+'.elf').exists():
        old_label = V8
    else:
        old_label = V7
    old, aold, endold, marginold = inspect(out, old_label)
    if b81 == old:
        raise ValueError('V8.1 BIN is identical to comparison BIN')
    if len(b81) != len(old):
        raise ValueError('Firmware BIN length changed')
    if a81.get('.bss',(0,0))[1] != aold.get('.bss',(0,0))[1]:
        raise ValueError('Unexpected extra RAM .bss')
    if a81.get('.data',(0,0))[1] != aold.get('.data',(0,0))[1]:
        raise ValueError('Unexpected .data change')
    lines = [
        'AUDIT OpenGD77 MD-UV380 RX/TX Dual Watch V8.1 - R20260131 (experimental)',
        'Version affichée: R20260131-DW8.1 (ON-SCREEN ONLY; USB identifier unchanged)',
        'Contributeur supplémentaire: F4EGM (RX/TX Watch)',
        'Original contributor credits preserved.',
        'Firmware is NOT official R20260504.',
        '',
        f'Comparison: {old_label}',
        f'V8.1 : {V81}',
        f'BIN length: {len(b81)} bytes',
        f'BIN SHA256: {hashlib.sha256(b81).hexdigest()}',
        f'ELF .text: {a81.get(".text",(0,0))[1]} bytes',
        f'ELF .rodata: {a81.get(".rodata",(0,0))[1]} bytes',
        f'ELF .data: {a81.get(".data",(0,0))[1]} bytes',
        f'ELF .bss: {a81.get(".bss",(0,0))[1]} bytes',
        f'Free Flash before AMBE codec (FF checked): {margin81} bytes',
        f'Flash margin delta versus reference: {margin81-marginold:+d} bytes',
        f'Different BIN bytes: {sum(x!=y for x,y in zip(old,b81))}',
        '',
        'Sections delta:'
    ]
    for sect in ('.text','.rodata','.data','.bss'):
        n = a81.get(sect,(0,0))[1]-aold.get(sect,(0,0))[1]
        lines.append(f'  {sect}: {n:+d} bytes')
    lines += [
        '',
        'Important: V8.1 patch modifies firmware-info/credits only versus V8.',
        'If built straight from V7, it also applies V8 larger DW label (single-line patch).',
        'No changes to codeplug or RF operation in this patch.',
        'Full ARM build validated; screen appearance / persistence still requires radio if relevant.',
        'CPS Web may still erase the custom per-channel DW bit when rewriting entire codeplug.'
    ]
    text = '\n'.join(lines)+'\n'
    (out/'AUDIT_DUALWATCH_V81.txt').write_text(text,encoding='utf-8')
    print(text)

if __name__ == '__main__':
    try:
        if len(sys.argv) != 2:
            raise ValueError('Usage: python3 audit_v81.py output_directory')
        report(Path(sys.argv[1]))
    except (OSError, ValueError) as e:
        print('[ERROR]',e,file=sys.stderr)
        sys.exit(2)
