#!/usr/bin/env bash
# MD-UV380 R20260131 - F4EGM Dual Watch V8.1 cosmetic build.
# Advances V7->V8 on source if needed, then adds contributor and version only.
# Never opens USB or writes the radio / codeplug.
set -Eeuo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$DIR/opengd77_rxtx_build"
MOD="$ROOT/sources_modifiees"
FW="$MOD/MDUV380_firmware"
OUT="$ROOT/resultats"
LOG="$ROOT/logs"
V7="OpenGD77_MDUV380_R20260131_RXTX_DUALWATCH_V7_PERCHANNEL_EXPERIMENTAL"
V81="OpenGD77_MDUV380_R20260131_F4EGM_DW_V8_1_EXPERIMENTAL"
ENGINE="${ENGINE:-podman}"
JOBS="${JOBS:-4}"
CHECK=0
if [[ "${1:-}" == "--check-only" && "$#" -eq 1 ]]; then CHECK=1
elif [[ "$#" -ne 0 ]]; then
  echo 'Usage: bash build_v81_debian13.sh [--check-only]' >&2; exit 2
fi
[[ -f "$FW/Makefile" ]] || { echo '[ERROR] Existing sources_modifiees/MDUV380_firmware missing.' >&2; exit 2; }
[[ -s "$OUT/$V7.bin" && -s "$OUT/$V7.elf" ]] || {
  echo '[ERROR] V7 BIN and ELF missing; use previous successful V7 build.' >&2; exit 2;
}
mkdir -p "$OUT" "$LOG"
python3 "$DIR/tests/test_v81.py"
python3 "$DIR/upgrade_v8_to_v81.py" "$MOD" --check
if [[ "$CHECK" == 1 ]]; then
  echo '[OK] V8.1 source verified. No changes made.'
  exit 0
fi
case "$ENGINE" in
  podman|docker)
    command -v "$ENGINE" >/dev/null || { echo "[ERROR] Missing $ENGINE" >&2; exit 2; } ;;
  native)
    command -v arm-none-eabi-gcc >/dev/null || { echo '[ERROR] Missing arm-none-eabi-gcc' >&2; exit 2; } ;;
  *) echo '[ERROR] ENGINE must be podman, docker or native.' >&2; exit 2 ;;
esac
python3 "$DIR/upgrade_v8_to_v81.py" "$MOD" --apply
printf '[INFO] Rebuilding V8.1 with %s\n' "$ENGINE"
if [[ "$ENGINE" == native ]]; then
  make -C "$FW" clean > "$LOG/v81_compilation.log" 2>&1
  if ! make -C "$FW" -j"$JOBS" all PLATFORM=MDUV380 >> "$LOG/v81_compilation.log" 2>&1; then
    tail -n 75 "$LOG/v81_compilation.log" >&2; exit 1
  fi
else
  if ! make -C "$FW" rebuild "CONTAINER_ENGINE=$ENGINE" "JOBS=$JOBS" PLATFORM=MDUV380 > "$LOG/v81_compilation.log" 2>&1; then
    tail -n 75 "$LOG/v81_compilation.log" >&2; exit 1
  fi
fi
[[ -s "$FW/build/OpenGD77_MDUV380.bin" && -s "$FW/build/MDUV380_FW.elf" && -s "$FW/build/MDUV380_FW.map" ]] || {
  echo '[ERROR] Missing BIN/ELF/MAP output from Makefile.' >&2; exit 2
}
cp -- "$FW/build/OpenGD77_MDUV380.bin" "$OUT/$V81.bin"
cp -- "$FW/build/MDUV380_FW.elf" "$OUT/$V81.elf"
cp -- "$FW/build/MDUV380_FW.map" "$OUT/$V81.map"
python3 "$DIR/audit_v81.py" "$OUT"
printf '\n[OK] V8.1: %s\n' "$OUT/$V81.bin"
echo '[INFO] V7/V8 builds and source backups retained for rollback.'
