#!/usr/bin/env python3
"""Cosmetic V8 -> V8.1 update: add F4EGM credit and visible DW version.

Optionally advances V7's DW font to V8 when the V8 package is not yet built.
No radio I/O or codeplug changes. Refuses unknown upstream source revisions.
"""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import sys
import tempfile
from upgrade_v7_to_v8 import (
    SRC as CHANNEL_SRC,
    HEADER,
    V7_DRAW,
    V8_DRAW,
    validate_source,
    transform as channel_transform,
    atomic_replace,
)

CREDITS_SRC = Path('MDUV380_firmware/application/source/user_interface/menuFirmwareInfoScreen.c')
CREDIT_ANCHOR = b'"Jason VK7ZJA (SK)"'
CREDIT_INSERT = b'''"Jason VK7ZJA (SK)"
#if defined(PLATFORM_MDUV380)
        , "F4EGM (RX/TX Watch)"
#endif'''
# A single additional line underneath CPU Flash and above the navigation triangle.
# Anchor on the CPU Flash field and the immediately following closing #endif.
# The old V8.1 patch matched the *entire* navigation-triangle tail; harmless
# whitespace or minor changes to that tail caused a false rejection.
VERSION_ANCHOR = b'''displayPrintAt(8, 94, cpuTypeBuf , FONT_SIZE_2);\n#endif'''
VERSION_INSERT = VERSION_ANCHOR + b'''\n#if defined(PLATFORM_MDUV380)
\tdisplayPrintCentered(110, "R20260131-DW8.1", FONT_SIZE_2);
#endif'''
BACKUP = '.BEFORE_V81.bak'


def transform_credits(raw: bytes) -> tuple[bytes, bool]:
    if b'\x00' in raw:
        raise ValueError('menuFirmwareInfoScreen.c contains NUL bytes')
    if b'static const char *creditTexts[]' not in raw or b'maxDisplayedCreditsLines' not in raw:
        raise ValueError('Unrecognized OpenGD77 credits source')
    if b'displayPrintAt(8, 94, cpuTypeBuf , FONT_SIZE_2);' not in raw:
        raise ValueError('MD-UV380 firmware information geometry changed')
    # Keep original source line endings intact (CRLF or LF).
    nl = b'\r\n' if b'\r\n' in raw else b'\n'
    data = raw.replace(b'\r\n', b'\n')
    has_credit = b'"F4EGM (RX/TX Watch)"' in data
    has_version = b'"R20260131-DW8.1"' in data
    if has_credit != has_version:
        raise ValueError('Partial or inconsistent V8.1 source detected')
    if has_credit and has_version:
        if data.count(CREDIT_INSERT) != 1 or data.count(VERSION_INSERT) != 1:
            raise ValueError('Existing V8.1 patch differs from expected structure')
        return raw, False
    if data.count(CREDIT_ANCHOR) != 1:
        raise ValueError('Credits anchor missing or duplicated')
    if data.count(VERSION_ANCHOR) != 1:
        # Expose a precise, non-sensitive source diagnostic if a different
        # firmware version has changed the CPU Flash field.
        marker = data.find(b'displayPrintAt(8, 94,')
        if marker < 0:
            raise ValueError('Firmware info: CPU Flash display line not found (different source revision)')
        nearby = data[max(0, marker-80):marker+220].decode('utf-8', errors='replace').replace('\n', '\\n')
        raise ValueError(f'Firmware info: expected closing #endif missing after CPU Flash: {nearby}')
    # Restrict the injection to the firmware-build page, not another display
    # function or a copied fragment elsewhere in the source file.
    build_start = data.find(b'static void displayBuildDetails(bool playVP)\n{')
    credit_start = data.find(b'static void displayCredits(bool playVP, uint32_t pageNumber)\n{')
    match_at = data.find(VERSION_ANCHOR)
    if not (0 <= build_start < match_at < credit_start):
        raise ValueError('Firmware info: CPU Flash anchor outside displayBuildDetails')
    if b'displayRender();' not in data[match_at:credit_start]:
        raise ValueError('Firmware info: missing rendering call after CPU Flash')
    new = data.replace(CREDIT_ANCHOR, CREDIT_INSERT, 1).replace(VERSION_ANCHOR, VERSION_INSERT, 1)
    assert new.count(b'"F4EGM (RX/TX Watch)"') == 1
    assert new.count(b'"R20260131-DW8.1"') == 1
    if nl == b'\r\n':
        new = new.replace(b'\n', b'\r\n')
    return new, True


def preflight(root: Path):
    paths = (root / CHANNEL_SRC, root / HEADER, root / CREDITS_SRC)
    if not all(p.is_file() for p in paths):
        raise ValueError('Missing existing OpenGD77 source(s) in sources_modifiees')
    channel, header, credits = (p.read_bytes() for p in paths)
    validate_source(channel, header)
    patched_channel, channel_change = channel_transform(channel, header)
    if not channel_change and channel.count(V8_DRAW) != 1:
        raise ValueError('V8 layout is not as expected')
    patched_credits, credits_change = transform_credits(credits)
    return paths, (channel, credits), (patched_channel, patched_credits), (channel_change, credits_change)


def install(root: Path, apply: bool) -> None:
    paths, originals, patched, changes = preflight(root)
    channel_path, _header_path, credits_path = paths
    print(f'[V8.1] Current display: {"V7 (will advance to V8)" if changes[0] else "V8"}')
    print(f'[V8.1] Firmware info: {"will add version+F4EGM" if changes[1] else "already patched"}')
    if not apply:
        print('[V8.1] Check successful. Source, codeplug and radio unchanged.')
        return
    targets = [(channel_path, originals[0], patched[0], '.BEFORE_V8.bak', changes[0]),
               (credits_path, originals[1], patched[1], BACKUP, changes[1])]
    # Precheck all backups *before* making a change.
    for path, old, new, suffix, change in targets:
        if not change:
            continue
        backup = path.with_name(path.name + suffix)
        if backup.exists():
            raise ValueError(f'Backup already present, refusing overwrite: {backup}')
    # Save originals safely and modify only files that need changes.
    written: list[tuple[Path, bytes]] = []
    try:
        for path, old, new, suffix, change in targets:
            if not change:
                continue
            backup = path.with_name(path.name + suffix)
            with backup.open('xb') as f:
                f.write(old)
                f.flush()
                os.fsync(f.fileno())
            atomic_replace(path, new)
            written.append((path, old))
    except BaseException:
        for path, old in reversed(written):
            atomic_replace(path, old)
        raise
    print('[V8.1] Applied successfully. RF, PTT, RX/TX timers, menus and codeplug remain unchanged.')


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('modified_source_root', type=Path)
    group = ap.add_mutually_exclusive_group(required=True)
    group.add_argument('--check', action='store_true')
    group.add_argument('--apply', action='store_true')
    args = ap.parse_args()
    try:
        install(args.modified_source_root, args.apply)
        return 0
    except (OSError, ValueError) as ex:
        print('[ERROR]', ex, file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
