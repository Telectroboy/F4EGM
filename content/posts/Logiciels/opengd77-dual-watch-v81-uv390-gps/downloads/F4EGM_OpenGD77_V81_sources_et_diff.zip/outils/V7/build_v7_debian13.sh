#!/usr/bin/env bash
# Debian 13: checks, patches and builds MD-UV380 R20260131 RX/TX Watch V7.
set -Eeuo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$DIR/opengd77_rxtx_build"
MOD="$ROOT/sources_modifiees"
FW="$MOD/MDUV380_firmware"
OUT="$ROOT/resultats"
LOG="$ROOT/logs"
V5="OpenGD77_MDUV380_R20260131_RXTX_DUALWATCH_EXPERIMENTAL"
V7="OpenGD77_MDUV380_R20260131_RXTX_DUALWATCH_V7_PERCHANNEL_EXPERIMENTAL"
ENGINE="${ENGINE:-podman}"
JOBS="${JOBS:-4}"
CHECK=0
if [[ "${1:-}" == "--check-only" ]]; then CHECK=1;
elif [[ $# -ne 0 ]]; then echo 'Usage: bash build_v7_debian13.sh [--check-only]' >&2; exit 2; fi
[[ -f "$FW/Makefile" ]] || { echo '[ERROR] Existing sources_modifiees not found.' >&2; exit 2; }
[[ -s "$OUT/$V5.bin" && -s "$OUT/$V5.elf" ]] || { echo '[ERROR] V5 results missing; compile V5 first.' >&2; exit 2; }
mkdir -p "$OUT" "$LOG"
python3 "$DIR/tests/test_v7.py"
python3 "$DIR/upgrade_v5_to_v7.py" "$MOD" --check
if [[ "$CHECK" == 1 ]]; then
  echo '[OK] V7 check-only: no source or radio was changed.'
  exit 0
fi
case "$ENGINE" in
  podman|docker) command -v "$ENGINE" >/dev/null || { echo "[ERROR] $ENGINE missing" >&2; exit 2; } ;;
  native) command -v arm-none-eabi-gcc >/dev/null || { echo '[ERROR] arm-none-eabi-gcc missing' >&2; exit 2; } ;;
  *) echo '[ERROR] ENGINE must be podman, docker or native' >&2; exit 2 ;;
esac
python3 "$DIR/upgrade_v5_to_v7.py" "$MOD" --apply
printf '[INFO] Building V7 with %s\n' "$ENGINE"
if [[ "$ENGINE" == native ]]; then
  make -C "$FW" clean > "$LOG/v7_compilation.log" 2>&1
  if ! make -C "$FW" -j"$JOBS" all PLATFORM=MDUV380 >> "$LOG/v7_compilation.log" 2>&1; then
    tail -n 75 "$LOG/v7_compilation.log" >&2
    exit 1
  fi
else
  if ! make -C "$FW" rebuild "CONTAINER_ENGINE=$ENGINE" "JOBS=$JOBS" PLATFORM=MDUV380 > "$LOG/v7_compilation.log" 2>&1; then
    tail -n 75 "$LOG/v7_compilation.log" >&2
    exit 1
  fi
fi
[[ -s "$FW/build/OpenGD77_MDUV380.bin" && -s "$FW/build/MDUV380_FW.elf" && -s "$FW/build/MDUV380_FW.map" ]] || {
 echo '[ERROR] V7 BIN / ELF / MAP missing. Check build log.' >&2; exit 2;
}
cp -- "$FW/build/OpenGD77_MDUV380.bin" "$OUT/$V7.bin"
cp -- "$FW/build/MDUV380_FW.elf" "$OUT/$V7.elf"
cp -- "$FW/build/MDUV380_FW.map" "$OUT/$V7.map"
python3 "$DIR/audit_v7.py" "$OUT"
printf '\n[OK] V7 experimental bin: %s\n' "$OUT/$V7.bin"
echo '[IMPORTANT] Review the audit before flashing; web CPS may discard the new per-channel flag when re-uploading the codeplug.'
