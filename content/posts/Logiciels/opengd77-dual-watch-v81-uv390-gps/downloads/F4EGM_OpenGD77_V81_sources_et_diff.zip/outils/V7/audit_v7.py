#!/usr/bin/env python3
"""Read-only, stdlib-only comparison of V5 and V7 linked outputs."""
from pathlib import Path
import hashlib
import struct
import sys

BASE = 'OpenGD77_MDUV380_R20260131_base'
V5 = 'OpenGD77_MDUV380_R20260131_RXTX_DUALWATCH_EXPERIMENTAL'
V7 = 'OpenGD77_MDUV380_R20260131_RXTX_DUALWATCH_V7_PERCHANNEL_EXPERIMENTAL'
CODEC = 0x0807537C
FLASH = 0x0800C000


def elf_alloc(path):
    raw = path.read_bytes()
    if raw[:6] != b'\x7fELF\x01\x01' or struct.unpack_from('<H', raw, 18)[0] != 40:
        raise RuntimeError('Invalid little-endian ARM ELF: ' + str(path))
    off, ent, count, names_idx = (struct.unpack_from('<I',raw,32)[0], struct.unpack_from('<H',raw,46)[0],
        struct.unpack_from('<H',raw,48)[0], struct.unpack_from('<H',raw,50)[0])
    hs = [struct.unpack_from('<10I',raw,off+i*ent) for i in range(count)]
    s = hs[names_idx]
    names=raw[s[4]:s[4]+s[5]]
    alloc={}
    for h in hs:
        if h[2] & 2 and h[5]:
            name=names[h[0]:names.find(b'\x00',h[0])].decode('ascii','replace')
            alloc[name]=(h[3],h[5])
    return alloc


def report(out):
    rows={}
    lines=['AUDIT RX/TX WATCH V7 - R20260131 (not R20260504)', '']
    for v in [BASE,V5,V7]:
        b=out/(v+'.bin'); e=out/(v+'.elf')
        if not b.is_file() or not e.is_file(): raise RuntimeError('Missing: '+str(b)+' or ELF')
        data=b.read_bytes(); alloc=elf_alloc(e); rows[v]=(data,alloc)
        flashend=max((addr+sz for name,(addr,sz) in alloc.items() if FLASH<=addr<CODEC and addr+sz<=CODEC),default=0)
        lines.append(f'{v}: {len(data)} octets, SHA256 {hashlib.sha256(data).hexdigest()}')
        lines.append(f'  text={alloc.get(".text",(0,0))[1]}, rodata={alloc.get(".rodata",(0,0))[1]}, bss={alloc.get(".bss",(0,0))[1]}')
        lines.append(f'  Flash margin before reserved codec: {CODEC-flashend} bytes' if flashend else '  Unknown pre-codec margin')
        if v == V7:
            lines.append(f'  status label DW:R in BIN: {b"DW:R" in data}')
            lines.append(f'  status label DW:T in BIN: {b"DW:T" in data}')
    lines.append('')
    for a,b in ((BASE,V7),(V5,V7)):
        lines.append(f'Delta {a} -> {b}:')
        for section in ['.text','.rodata','.data','.bss']:
            diff=rows[b][1].get(section,(0,0))[1]-rows[a][1].get(section,(0,0))[1]
            lines.append(f'  {section}: {diff:+d} bytes')
    data,alloc=rows[V7]
    end=max((addr+sz for name,(addr,sz) in alloc.items() if FLASH<=addr<CODEC and addr+sz<=CODEC),default=0)
    if end and CODEC-end < 16384:
        lines.append('WARNING: pre-codec margin <16K')
    if rows[V5][0] == data:
        lines.append('ERROR: V5 and V7 bins identical')
        raise RuntimeError('\n'.join(lines))
    lines += ['','V7 is unvalidated on hardware. Persistence is per analogue memory using flag 0x02 at offset 0x26.',
              'On/Off in Quick Menu changes one channel codeplug record. CPS Web may overwrite this unsupported flag on a full codeplug upload.']
    msg='\n'.join(lines)+'\n'
    (out/'AUDIT_DUALWATCH_V7.txt').write_text(msg,encoding='utf-8')
    print(msg)

if __name__=='__main__':
    try: report(Path(sys.argv[1]))
    except (OSError,RuntimeError,struct.error,IndexError) as ex:
        print('[ERROR]',ex,file=sys.stderr); sys.exit(2)
