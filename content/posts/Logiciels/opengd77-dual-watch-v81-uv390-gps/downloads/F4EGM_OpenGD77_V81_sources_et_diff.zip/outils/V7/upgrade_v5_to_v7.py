#!/usr/bin/env python3
"""OpenGD77 RX/TX Dual Watch V7: channel-local persistent flag and extra status row.

Transactional source-only patch. Accepts V5 and optionally rebases V6 using its
verified V5 backups. Only changes the *modified* source tree, never the radio.
"""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import tempfile

SRC = Path('MDUV380_firmware/application/source/user_interface/uiChannelMode.c')
CODEPLUG = Path('MDUV380_firmware/application/include/functions/codeplug.h')
SETTINGS = Path('MDUV380_firmware/application/include/functions/settings.h')
MARKER = 'V7: channel-local persistent watch; separate status row'
BITNAME = 'CODEPLUG_CHANNEL_LIBREDMR_FLAG1_RXTX_WATCH'


def replace_one(text: str, old: str, new: str, reason: str) -> str:
    occurrences = text.count(old)
    if occurrences != 1:
        raise ValueError(f'{reason}: expected exactly one anchor, found {occurrences}; no file changed')
    return text.replace(old, new, 1)


def patch_channel(text: str) -> str:
    if MARKER in text:
        raise ValueError('V7 is already present')
    text = replace_one(text, ' * V5: keyboard events do not break a locked reception.',
        ' * ' + MARKER + '.\n * V5: keyboard events do not break a locked reception.', 'revision marker')
    text = replace_one(text, 'static bool rxTxMenuChoice;\n', '''static bool rxTxMenuChoice;

/* On MD-UV380 channel-mode, the 0x02 channel flag is unused in R20260131.
 * This is a per-channel setting stored in the existing 56-byte record.
 * Never change the live channel's RX/TX frequencies to persist this flag. */
static bool rxTxSavedForThisChannel(void)
{
 return currentChannelData &&
        ((currentChannelData->LibreDMR_flag1 & CODEPLUG_CHANNEL_LIBREDMR_FLAG1_RXTX_WATCH) != 0);
}

static bool rxTxSaveForThisChannel(bool enabled)
{
 const int index = uiDataGlobal.currentSelectedChannelNumber;
 if (!currentChannelData || index < CODEPLUG_CHANNELS_MIN || index > CODEPLUG_CHANNELS_MAX)
  return false;

 /* Read from NVM rather than persisting temporary changes to currentChannelData. */
 CodeplugChannel_t stored;
 codeplugChannelGetDataForIndex(index, &stored);
 uint8_t newFlags = enabled ?
  (stored.LibreDMR_flag1 | CODEPLUG_CHANNEL_LIBREDMR_FLAG1_RXTX_WATCH) :
  (stored.LibreDMR_flag1 & (uint8_t)~CODEPLUG_CHANNEL_LIBREDMR_FLAG1_RXTX_WATCH);
 if (newFlags != stored.LibreDMR_flag1)
 {
  stored.LibreDMR_flag1 = newFlags;
  if (!codeplugChannelSaveDataForIndex(index, &stored)) return false;
 }
 currentChannelData->LibreDMR_flag1 = newFlags;
 return true;
}

static uint8_t rxTxDisplayStatus(void)
{
 if (rxTxState == RXTX_OFF) return 0U;
 if (rxTxState == RXTX_LOCK_RX) return 1U;
 if (rxTxState == RXTX_LOCK_TX) return 2U;
 return 3U;
}
''', 'per-channel setting and status helpers')

    text = replace_one(text, '''#if defined(PLATFORM_MDUV380)
		rxTxTick(ev);
#endif
''', '''#if defined(PLATFORM_MDUV380)
		/* Redraw only on start/stop of a valid reception, not every RF retune. */
		uint8_t rxTxPreviousLabel = rxTxDisplayStatus();
		rxTxTick(ev);
		if (rxTxPreviousLabel != rxTxDisplayStatus())
		{
			uiDataGlobal.displayQSOState = QSO_DISPLAY_DEFAULT_SCREEN;
			uiChannelModeUpdateScreen(0);
		}
#endif
''', 'refresh on valid lock/unlock')

    text = replace_one(text, '''	if (uiDataGlobal.Scan.active == false)
	{
		checkChannelLocation(currentChannelData);

		if (useChannelDataInMemory == false)
		{
			aprsBeaconingResetTimers();
		}
	}
}

void uiChannelModeUpdateScreen(int txTimeSecs)
''', '''	if (uiDataGlobal.Scan.active == false)
	{
		checkChannelLocation(currentChannelData);

		if (useChannelDataInMemory == false)
		{
			aprsBeaconingResetTimers();
		}
	}
#if defined(PLATFORM_MDUV380)
	/* Restore this channel's own watch flag on boot or channel change. */
	if (rxTxSavedForThisChannel())
	{
		rxTxStart();
	}
#endif
}

void uiChannelModeUpdateScreen(int txTimeSecs)
''', 'restore after loading channel')

    text = replace_one(text, '''			if (!uiDataGlobal.displayChannelSettings)
			{
				int8_t yOverride = (isTransmitting ?''', '''#if defined(PLATFORM_MDUV380)
			/* A new small line between the header and channel name: existing
			 * zone, channel name and frequency lines remain untouched. */
			if (!uiDataGlobal.displayChannelSettings && !isTransmitting && rxTxState != RXTX_OFF)
			{
				const char *dwLabel = (rxTxState == RXTX_LOCK_RX) ? "DW:R" :
					((rxTxState == RXTX_LOCK_TX) ? "DW:T" : "DW");
				displayThemeApply(THEME_ITEM_FG_CHANNEL_NAME, THEME_ITEM_BG);
				displayPrintCentered(DISPLAY_Y_POS_CHANNEL_FIRST_LINE - 12, dwLabel, FONT_SIZE_1);
				displayThemeResetToDefault();
			}
#endif
			if (!uiDataGlobal.displayChannelSettings)
			{
				int8_t yOverride = (isTransmitting ?''', 'additional UI line')

    text = replace_one(text, '\t\trxTxMenuChoice = (rxTxState != RXTX_OFF);\n',
        '\t\trxTxMenuChoice = rxTxSavedForThisChannel();\n', 'quick-menu status')
    text = replace_one(text, '''					if (menuDataGlobal.currentItemIndex == CH_SCREEN_QUICK_MENU_RXTX_WATCH)
					{
						if (rxTxMenuChoice)
						{
							rxTxStart();
						}
						else
						{
							rxTxStop();
						}
					}
''', '''					if (menuDataGlobal.currentItemIndex == CH_SCREEN_QUICK_MENU_RXTX_WATCH)
					{
						/* Only write once after explicit confirmation, never in the RF tick. */
						if (rxTxAvailable() || !rxTxMenuChoice)
						{
							if (rxTxSaveForThisChannel(rxTxMenuChoice))
							{
								if (rxTxMenuChoice) rxTxStart();
								else rxTxStop();
							}
							else
							{
								menuQuickChannelExitStatus |= MENU_STATUS_ERROR;
							}
						}
					}
''', 'quick-menu persistence')
    return text


def patch_codeplug_header(text: str) -> str:
    return replace_one(text, '#define CODEPLUG_CHANNEL_LIBREDMR_FLAG1_FORCE_DMO                0x04',
        '#define CODEPLUG_CHANNEL_LIBREDMR_FLAG1_FORCE_DMO                0x04\n'
        '#if defined(PLATFORM_MDUV380)\n'
        '#define CODEPLUG_CHANNEL_LIBREDMR_FLAG1_RXTX_WATCH              0x02 /* bit 1 unused in R20260131 */\n'
        '#endif', 'channel flag definition')


def source_text(path: Path) -> tuple[str, bool]:
    data = path.read_bytes()
    if b'\0' in data:
        raise ValueError(f'binary input refused: {path}')
    return data.replace(b'\r\n', b'\n').decode('utf-8'), b'\r\n' in data


def encode(text: str, crlf: bool) -> bytes:
    data = text.encode('utf-8')
    return data.replace(b'\n', b'\r\n') if crlf else data


def atomic_write(path: Path, data: bytes) -> None:
    mode = path.stat().st_mode & 0o777
    temp = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix=path.name+'.tmp-', delete=False) as fp:
            temp = Path(fp.name)
            fp.write(data)
            fp.flush()
            os.fsync(fp.fileno())
        os.chmod(temp, mode)
        os.replace(temp, path)
    finally:
        if temp is not None and temp.exists():
            temp.unlink()


def update(root: Path, do_apply: bool):
    channel = root / SRC
    header = root / CODEPLUG
    settings = root / SETTINGS
    for path in (channel, header):
        if not path.is_file():
            raise ValueError('missing file ' + str(path))
    source, line_crlf = source_text(channel)
    base_from_v6 = False
    if MARKER in source:
        if BITNAME not in source_text(header)[0]:
            raise ValueError('partial V7 detected, refusal')
        print('[V7] Already applied; no changes.')
        return
    if 'V6: persistent RX/TX watch' in source:
        old = channel.with_name(channel.name + '.V5_BEFORE_V6.bak')
        old_settings = settings.with_name(settings.name + '.V5_BEFORE_V6.bak')
        if not old.is_file() or not old_settings.is_file():
            raise ValueError('V6 detected but V5 backups missing: no modifications')
        source, line_crlf = source_text(old)
        base_from_v6 = True
    if 'V5: keyboard events do not break a locked reception.' not in source:
        raise ValueError('Expected exact V5 source revision; no modifications')
    head, head_crlf = source_text(header)
    if BITNAME in head:
        raise ValueError('channel flag already allocated; no modifications')
    patched_channel = encode(patch_channel(source), line_crlf)
    patched_header = encode(patch_codeplug_header(head), head_crlf)
    changes = {channel: patched_channel, header: patched_header}
    if base_from_v6:
        settings_current, _ = source_text(settings)
        if 'BIT_RXTX_WATCH_ENABLED' not in settings_current:
            raise ValueError('V6 settings header unexpectedly lacks previous marker')
        changes[settings] = settings.with_name(settings.name+'.V5_BEFORE_V6.bak').read_bytes()
    if not do_apply:
        print(f'[V7] Exact sources verified; {len(changes)} files would be patched; none modified.')
        print('[V7] Input:', 'V6 -> V5 backup -> V7' if base_from_v6 else 'V5 -> V7')
        return
    original = {p:p.read_bytes() for p in changes}
    backups = {p:p.with_name(p.name+'.BEFORE_V7.bak') for p in changes}
    for p in backups.values():
        if p.exists():
            raise ValueError(f'existing V7 backup {p}: refusal to overwrite')
    for orig, back in backups.items():
        with back.open('xb') as f:
            f.write(original[orig]); f.flush(); os.fsync(f.fileno())
    try:
        for path, data in changes.items():
            atomic_write(path, data)
            print('[PATCHED]', path)
    except BaseException:
        for path, data in original.items():
            if path.read_bytes() != data:
                atomic_write(path, data)
        raise
    print('[V7] Done. Original sources preserved in *.BEFORE_V7.bak')
    print('[V7] No radio or codeplug has been modified.')


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('modified_source_root', type=Path)
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument('--check', action='store_true')
    g.add_argument('--apply', action='store_true')
    a = p.parse_args()
    try:
        update(a.modified_source_root, a.apply)
    except (OSError, ValueError) as e:
        p.exit(1, '[ERREUR] ' + str(e) + '\n')
