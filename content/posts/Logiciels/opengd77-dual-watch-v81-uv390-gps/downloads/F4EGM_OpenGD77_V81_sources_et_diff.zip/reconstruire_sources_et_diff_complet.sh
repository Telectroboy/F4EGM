#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PIN=b7a0d368a458291c66e6fb1431d7c78627727381
URL=https://github.com/mangelajo/opengd77-rt3s-experiments.git
OUT="${1:-$ROOT/sources_completes_reconstituees}"
mkdir -p "$OUT"
OUT="$(cd "$OUT" && pwd)"
for cmd in git python3 diff tar; do command -v "$cmd" >/dev/null || { echo "[ERREUR] $cmd absent" >&2; exit 2; }; done
SRC="$OUT/source_originale_R20260131"
MOD="$OUT/source_modifiee_F4EGM_V81"
if [[ ! -d "$SRC/.git" ]]; then
  mkdir -p "$SRC"
  git -C "$SRC" init -q
  git -C "$SRC" remote add origin "$URL"
  git -C "$SRC" fetch --depth=1 origin "$PIN"
  git -C "$SRC" checkout -q --detach FETCH_HEAD
fi
ACTUAL="$(git -C "$SRC" rev-parse HEAD)"
[[ "$ACTUAL" == "$PIN" ]] || { echo "[ERREUR] Revision non attendue: $ACTUAL" >&2; exit 2; }
[[ -f "$SRC/MDUV380_firmware/application/source/user_interface/uiChannelMode.c" ]] || { echo "[ERREUR] Arbre amont absent" >&2; exit 2; }
[[ ! -e "$MOD" ]] || { echo "[ERREUR] Dossier modifie deja existant: $MOD" >&2; exit 2; }
mkdir -p "$MOD"
cp -a "$SRC/." "$MOD/"
# Aucune compilation ni emission radio. On applique uniquement les sources.
python3 "$ROOT/outils/V5/patch_opengd77_dual_watch.py" "$MOD" --apply --core "$ROOT/outils/V5/rx_tx_watch_core.cfrag"
python3 "$ROOT/outils/V7/upgrade_v5_to_v7.py" "$MOD" --apply
python3 "$ROOT/outils/V81/upgrade_v8_to_v81.py" "$MOD" --apply
# Empecher les backups de polluer le diff.
diff -ruN --exclude='.git' --exclude='*.bak' --exclude='*.dualwatch.bak' "$SRC/MDUV380_firmware/application" "$MOD/MDUV380_firmware/application" > "$OUT/DIFF_COMPLET_ORIGINE_VERS_F4EGM_V81.patch" || STATUS=$?
if [[ "${STATUS:-0}" != '0' && "${STATUS:-0}" != '1' ]]; then exit "$STATUS"; fi
printf '%s\n' "$PIN" > "$OUT/REVISION_SOURCE_ORIGINE.txt"
echo "[OK] Source originale et modifiee sauvegardees. Diff : $OUT/DIFF_COMPLET_ORIGINE_VERS_F4EGM_V81.patch"
